// 실습1) if문 내부의 코드가 실행되도록 변수 course에 올바른 값을 할당하세요.
let course;
if (course === 'seb fe') {
  console.log('변수 course에 "seb fe"를 할당했습니다.');
}
